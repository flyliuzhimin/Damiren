﻿#region 摘要信息
/// ****************************
/// SQL辅助类
/// 作者：Liu Zhimin
/// 时间：2013/6/20 14:58:04  
/// QQ:1228168881
/// CLR版本：4.0.30319.296  
/// 说明：
/// 唯一标识：d8508f1c-d28b-4879-9eb3-296484eda5d1  
/// ****************************
#endregion
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;


/// <summary>  
/// 时间：2013/6/20 14:58:04  
/// </summary>  
public static class SqlHalper
{
    #region 增删改
    /// <summary>
    /// 增删改
    /// </summary>
    /// <param name="sql">传入增删改语句</param>
    /// <param name="constr">传入查询字符串</param>
    public static void ExecuteNonQuery(string sql, string constr)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();

        cmd.CommandText = sql;
        con.ConnectionString = constr;
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }
    #endregion

    #region 查询单行单列的一个数据
    /// <summary>
    /// 查询单行单列的一个数据
    /// </summary>
    /// <param name="sql">传入的查询语句</param>
    /// <param name="constr">传入的连接字符串</param>
    /// <returns>返回一个string类型的数据</returns>
    public static string ExecuteScalar(string sql, string constr)
    {
        string temp = "";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();

        cmd.CommandText = sql;
        con.ConnectionString = constr;
        cmd.Connection = con;
        con.Open();
        try
        {
            if (cmd.ExecuteScalar() != null)
            {
                temp = cmd.ExecuteScalar().ToString();
            }
            else { temp = ""; }
        }
        catch (Exception ex)
        {
            
        }
        con.Close();
        return temp;
    }
    #endregion

    #region 执行查询语句，返回DataSet
    /// <summary>
    /// 执行查询语句，返回DataSet
    /// </summary>
    /// <param name="sql">查询语句</param>
    /// <param name="connection">连接字符串</param>
    /// <returns>返回DataSet</returns>
    public static DataSet QueryDataSet(string sql, string connection)
    {
        DataTable dt = QueryDataTable(sql, connection);
        DataSet ds = new DataSet();
        ds.Tables.Add(dt);
        return ds;
    }
    #endregion

    #region 执行查询语句，返回DataTalbe
    /// <summary>
    /// 执行查询语句，返回DataTalbe
    /// </summary>
    /// <param name="sql">查询语句</param>
    /// <param name="connection">连接字符串</param>
    /// <returns>返回DataTable</returns>
    public static DataTable QueryDataTable(string sql, string connection)
    {
        DataTable dt = new DataTable();
        try
        {
            SqlDataAdapter da = new SqlDataAdapter(sql, connection);
            da.Fill(dt);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
        return dt;
    }
    #endregion
}

