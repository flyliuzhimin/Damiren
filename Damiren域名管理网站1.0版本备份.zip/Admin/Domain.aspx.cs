﻿using System;
using System.Configuration;
using System.Data;
using System.Text;
public partial class Admin_Domain : System.Web.UI.Page
{
    public static string trstring = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        DataTable dt = SqlHalper.QueryDataTable("SELECT * from [Yumings]", ConfigurationManager.ConnectionStrings["damirendb"].ToString());
        StringBuilder sbu = new StringBuilder();
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["id"].ToString() != "" && dr["id"] != null)
                {
                    sbu.Append("<tr>");
                    sbu.Append("<td> " + dr["id"].ToString() + " </td>");
                    sbu.Append("<td> " + dr["yuming"].ToString() + " </td>");
                    sbu.Append("<td> " + dr["pingtai"].ToString() + " </td>");
                    sbu.Append("<td> " + dr["hanyi"].ToString() + " </td>");
                    sbu.Append("<td> " + dr["chengben"].ToString() + " </td>");
                    sbu.Append("<td> ");
                    if (dr["lianjie"].ToString().Length > 20)
                    {
                        sbu.Append(dr["lianjie"].ToString().Substring(0, 20)+"...");
                    }
                    else
                    {
                        sbu.Append(dr["lianjie"].ToString());
                    }
                    sbu.Append("</td>");
                    sbu.Append("<td> " + dr["biaojia"].ToString() + " </td>");
                    sbu.Append("<td> " + dr["shoujia"].ToString() + " </td>");

                    if (dr["zhuangtai"].ToString().Trim() == "已售出")
                    {
                        sbu.Append("<td style='color:red;'>" + dr["zhuangtai"].ToString() + " </td>");
                    }
                    else if (dr["zhuangtai"].ToString().Trim() == "未售出")
                    {
                        sbu.Append("<td style='color:green;'>" + dr["zhuangtai"].ToString() + " </td>");
                    }
                    else {
                        sbu.Append("<td>" + dr["zhuangtai"].ToString() + " </td>");
                    }


                    sbu.Append("<td><a href = 'EditDomain.aspx?id=" + dr["id"].ToString() + "'>修改</a> <a href = 'PostDeleteDomain.aspx?id=" + dr["id"].ToString() + "'>删除</a></td>");
                    sbu.Append("</tr>");
                }
            }
        }
        trstring = sbu.ToString();


    }
}