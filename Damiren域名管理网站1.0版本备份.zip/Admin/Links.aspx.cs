﻿using System;
using System.Configuration;
using System.Data;
using System.Text;

public partial class Admin_Links : System.Web.UI.Page
{
    public static string trstring = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        DataTable dt = SqlHalper.QueryDataTable("SELECT * from [Links]",ConfigurationManager.ConnectionStrings["damirendb"].ToString());
StringBuilder sbu = new StringBuilder();
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["id"].ToString() != "" && dr["id"] != null)
                {
                    sbu.Append("<tr>");
                    sbu.Append("<td> " + dr["shunxu"].ToString() + " </td>");
                    sbu.Append("<td> " + dr["mingcheng"].ToString() + " </td>");
                    sbu.Append("<td> " + dr["dizhi"].ToString() + " </td>");
                    sbu.Append("<td><a href = 'EditLinks.aspx?id=" + dr["id"].ToString() + "'>修改</a> <a href = 'PostDeleteLinks.aspx?id=" + dr["id"].ToString() + "'>删除</a></td>");
                    sbu.Append("</tr>");
                }
            }
        }
        trstring = sbu.ToString();


    }
}