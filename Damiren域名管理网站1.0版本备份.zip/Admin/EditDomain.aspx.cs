﻿using System;
using System.Configuration;
using System.Data;

public partial class Admin_EditDomain : System.Web.UI.Page
{
    public string yuming = "";
    public string pingtai = "";
    public string hanyi = "";
    public string chengben = "";
    public string lianjie = "";
    public string biaojia = "";
    public string shoujia = "";
    public string zhuangtai = "";
    public string id = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        if (Request["id"].ToString() != "" && Request["id"] != null)
        {
            DataTable dt = SqlHalper.QueryDataTable("Select * from [Yumings] where id=" + Request["id"].ToString(), ConfigurationManager.ConnectionStrings["damirendb"].ToString());
            id = Request["id"].ToString();
            yuming = dt.Rows[0]["yuming"].ToString();
            pingtai = dt.Rows[0]["pingtai"].ToString();
            hanyi = dt.Rows[0]["hanyi"].ToString();
            chengben = dt.Rows[0]["chengben"].ToString();
            lianjie = dt.Rows[0]["lianjie"].ToString();
            biaojia = dt.Rows[0]["biaojia"].ToString();
            shoujia = dt.Rows[0]["shoujia"].ToString();
            zhuangtai = dt.Rows[0]["zhuangtai"].ToString();


            // Response.Redirect("Default.aspx");
        }
    }
}