﻿using System;
using System.Configuration;
using System.Data;

public partial class Admin_EditLinks : System.Web.UI.Page
{
    public string shunxu = "";
    public string mingcheng = "";
    public string dizhi = "";
    public string id = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        if (Request["id"].ToString() != "" && Request["id"] != null)
        {
            DataTable dt = SqlHalper.QueryDataTable("Select * from [Links] where id=" + Request["id"].ToString(), ConfigurationManager.ConnectionStrings["damirendb"].ToString());
            id = Request["id"].ToString();
            shunxu = dt.Rows[0]["shunxu"].ToString();
            mingcheng = dt.Rows[0]["mingcheng"].ToString();
            dizhi = dt.Rows[0]["dizhi"].ToString();


            // Response.Redirect("Default.aspx");
        }
    }
}