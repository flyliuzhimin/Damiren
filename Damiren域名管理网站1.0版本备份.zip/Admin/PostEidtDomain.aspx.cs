﻿using System;
using System.Configuration;

public partial class Admin_PostEidtDomain : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        string yuming = Request.Form["yuming"];
        string pingtai = Request.Form["pingtai"];
        string hanyi = Request.Form["hanyi"];
        string chengben = Request.Form["chengben"];
        string lianjie = Request.Form["lianjie"];
        string biaojia = Request.Form["biaojia"];
        string shoujia = Request.Form["shoujia"];
        string zhuangtai = Request.Form["zhuangtai"];
        string id = Request.Form["id"];

        try
        {
            SqlHalper.ExecuteNonQuery("update [Yumings] set [yuming]='"+yuming+"',[pingtai]='"+pingtai+"',[hanyi]='"+hanyi+"',[chengben]='"+chengben+"',[lianjie]='"+lianjie+"',[biaojia]='"+biaojia+"',[shoujia]='"+shoujia+"',[zhuangtai]='"+zhuangtai+"',[UpdateDate]='"+DateTime.Now+"' where id='"+id+"'", ConfigurationManager.ConnectionStrings["damirendb"].ToString());
        }
        catch (Exception err)
        {
            Response.Write(err.ToString());
        }
        finally
        {
            Response.Redirect("Domain.aspx");
        }
    }
}