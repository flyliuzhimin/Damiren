﻿using System;
using System.Configuration;
using System.Data;

public partial class Admin_Default : System.Web.UI.Page
{
   public int zaishuocount = 0;
    public int shouchucount = 0;
    public int huishoucount =0;
   public decimal touru = 0;
  public decimal yingli = 0;
  public decimal jinglirun = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        try
        {
            DataTable dt = SqlHalper.QueryDataTable("SELECT * from [Yumings] where [zhuangtai]='未售出'", ConfigurationManager.ConnectionStrings["damirendb"].ToString());
            zaishuocount = dt.Rows.Count;
        }
        catch { }
        try
        {
            shouchucount = SqlHalper.QueryDataTable("SELECT * from [Yumings] where [zhuangtai]='已售出'", ConfigurationManager.ConnectionStrings["damirendb"].ToString()).Rows.Count;
        }
        catch { }
        try
        {
            huishoucount = SqlHalper.QueryDataTable("SELECT * from [Yumings] where [zhuangtai]='已回收'", ConfigurationManager.ConnectionStrings["damirendb"].ToString()).Rows.Count;
        }
        catch { }
        touru = decimal.Parse( SqlHalper.ExecuteScalar("SELECT SUM(chengben) from [Yumings]", ConfigurationManager.ConnectionStrings["damirendb"].ToString()));
        yingli = decimal.Parse(SqlHalper.ExecuteScalar("SELECT SUM(shoujia-chengben) from [Yumings] where [zhuangtai]='已售出' or [zhuangtai]='已回收'", ConfigurationManager.ConnectionStrings["damirendb"].ToString()));
        jinglirun=
             decimal.Parse(SqlHalper.ExecuteScalar("SELECT SUM(shoujia-chengben) from [Yumings] ", ConfigurationManager.ConnectionStrings["damirendb"].ToString()));



    }
}