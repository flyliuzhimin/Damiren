﻿using System;

public partial class Admin_PostLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strUserName = Request.Form["username"];
        string strPWD = Request.Form["password"];

        if (strUserName == "liuzhimin" && strPWD == "Lht@2464092")
        {
            Session["user"] = "liuzhimin";
            Response.Redirect("Default.aspx");
        }
        else
        {
            Response.Redirect("Login.html");
        }
    }
}