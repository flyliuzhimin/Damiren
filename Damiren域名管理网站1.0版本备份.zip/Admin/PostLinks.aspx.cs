﻿using System;
using System.Configuration;

public partial class Admin_PostLinks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        string shunxu = Request.Form["shunxu"];
        string mingcheng = Request.Form["mingcheng"];
        string dizhi = Request.Form["dizhi"];

        try
        {
            SqlHalper.ExecuteNonQuery("INSERT INTO [Links]([shunxu],[mingcheng],[dizhi]) VALUES ('" + shunxu + "','" + mingcheng + "','" + dizhi + "')", ConfigurationManager.ConnectionStrings["damirendb"].ToString());
        }
        catch (Exception err)
        {
            Response.Write(err.ToString());
        }
        finally
        {
            Response.Redirect("Links.aspx");
        }
    }
}