﻿using System;
using System.Configuration;

public partial class Admin_PostDeleteDomain : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        if (Request["id"].ToString() != "" && Request["id"] != null)
        {
            SqlHalper.ExecuteNonQuery("Delete [Yumings] where id=" + Request["id"].ToString(), ConfigurationManager.ConnectionStrings["damirendb"].ToString());
            Response.Redirect("Domain.aspx");
        }
    }
}