﻿using System;
using System.Configuration;

public partial class Admin_PostCreateDomain : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] == null)
        {
            Response.Redirect("Login.html");
        }
        else
        {
            if (Session["user"].ToString() != "liuzhimin")
            {
                Response.Redirect("Login.html");
            }
        }
        string yuming = Request.Form["yuming"];
        string pingtai = Request.Form["pingtai"];
        string hanyi = Request.Form["hanyi"];
        string chengben = Request.Form["chengben"];
        string lianjie = Request.Form["lianjie"];
        string biaojia = Request.Form["biaojia"];
        string shoujia = Request.Form["shoujia"];
        string zhuangtai = Request.Form["zhuangtai"];

        try
        {
            SqlHalper.ExecuteNonQuery("INSERT INTO [Yumings]([yuming],[pingtai],[hanyi],[chengben],[lianjie],[biaojia],[shoujia],[zhuangtai],[CreateDate],[UpdateDate]) VALUES ('" + yuming + "','" + pingtai + "','" + hanyi + "','" + chengben+ "','" + lianjie+ "','" + biaojia + "','" + shoujia + "','" + zhuangtai + "','" + DateTime.Now + "','" + DateTime.Now + "')", ConfigurationManager.ConnectionStrings["damirendb"].ToString());
        }
        catch (Exception err)
        {
            Response.Write(err.ToString());
        }
        finally
        {
            Response.Redirect("Domain.aspx");
        }
    }
}